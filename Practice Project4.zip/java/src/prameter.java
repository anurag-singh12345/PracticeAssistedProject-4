public class ConstructorVerification {

    private int id;
    private String name;


    public ConstructorVerification() {
        System.out.println("Default Constructor");
        id = 0;
        name = "Default";
    }


    public ConstructorVerification(int id, String name) {
        System.out.println("Parameterized Constructor");
        this.id = id;
        this.name = name;
    }

    public ConstructorVerification(ConstructorVerification original) {
        System.out.println("Copy Constructor");
        this.id = original.id;
        this.name = original.name;
    }

   
    public void displayDetails() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println();
    }

    public static void main(String[] args) {
       

        
        ConstructorVerification defaultObject = new ConstructorVerification();
        defaultObject.displayDetails();

       
        ConstructorVerification parameterizedObject = new ConstructorVerification(1, "Anurag");
        parameterizedObject.displayDetails();

      
        ConstructorVerification originalObject = new ConstructorVerification(2, "Dipesh");
        ConstructorVerification copyObject = new ConstructorVerification(originalObject);
        copyObject.displayDetails();
    }
}